from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search tools',
    author='HF Python 2e',
    author_email='tiware23@gmail.com',
    url='headfirstlabscom',
    py_modules=['vsearch'],
)